

class User {
  constructor(db) {
    this.db = db;
  }

  async createUser(firstName, lastName, email, password) {
    const sql = `INSERT INTO users ('first name', 'last name', 'email', 'password') VALUES (?, ?, ?, ?)`;
    const values = [firstName, lastName, email, password];
    try {
      const result = await this.db.execute(sql, values)
      return result.insertId;
    } catch (error) {
      throw error;
    }
    

  }

}

module.exports = User