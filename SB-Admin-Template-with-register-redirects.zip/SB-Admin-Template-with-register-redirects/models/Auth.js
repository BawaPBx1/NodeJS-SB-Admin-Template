class Authenticate {
  constructor(db) {
    this.db = db;
  }
}

module.exports = Authenticate