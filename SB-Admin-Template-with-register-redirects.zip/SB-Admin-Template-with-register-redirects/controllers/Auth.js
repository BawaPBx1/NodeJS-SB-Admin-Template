const express = require('express');
const app = express();
const bcrypt = require('bcrypt');

const Auth = require('../models/Auth');
const db = require('../config/db');
    
const authModel = new Auth(db);

exports.index = (req, res) => {
    res.render('Auth');
};
exports.login = (req, res) => {
    res.render('Login');
};
exports.authenticate = (req, res) => {
    res.render('Login');
    console.log("authenticate", authModel)
};
